#!/usr/bin/env python3
"""
Compatibility module 
"""
import sys

IS_PY3 = sys.version_info[0] == 3